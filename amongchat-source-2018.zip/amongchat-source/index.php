<?php
require_once('amacha.php');
?>
